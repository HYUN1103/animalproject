from flask import Blueprint, request, jsonify, g, Flask
from pybo import db
from pybo.models import Card
from werkzeug.utils import secure_filename
import os

bp = Blueprint('card', __name__, url_prefix='/card')

#사진업로드 확인
@bp.route('/add', methods=['POST'])
def add_card():
    data = request.form
    title = data['title']
    text = data['text']
    image = request.files['image']
    
    if g.user is None:
        return jsonify({'error': 'Unauthorized'}), 401
    
    image_filename = secure_filename(image.filename)
    image_path = os.path.join('static/uploads', image_filename)
    image.save(image_path)
    
    card = Card(
        user_id=g.user.id,
        title=title,
        text=text,
        image_url=os.path.join('/static/uploads', image_filename)
    )
    db.session.add(card)
    db.session.commit()
    
    return jsonify({'success': True, 'image_url': card.image_url})

#사진목록확인
@bp.route('/list', methods=['GET'])
def list_cards():
    if g.user is None:
        return jsonify({'error': 'Unauthorized'}), 401
    
    cards = Card.query.filter_by(user_id=g.user.id).all()
    card_list = [{
        'id': card.id,
        'title': card.title,
        'text': card.text,
        'image_url': card.image_url,
        'username': card.user.username
    } for card in cards]
    
    return jsonify(card_list)

@bp.route('/delete/<int:card_id>', methods=['DELETE'])
def delete_card(card_id):
    card = Card.query.get(card_id)
    
    if card is None or card.user_id != g.user.id:
        return jsonify({'error': 'Unauthorized'}), 401
    
    db.session.delete(card)
    db.session.commit()
    
    return jsonify({'success': True})

@bp.route('/update/<int:card_id>', methods=['POST'])
def update_card(card_id):
    card = Card.query.get(card_id)
    
    if card is None or card.user_id != g.user.id:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.form
    card.title = data['title']
    card.text = data['text']
    
    if 'image' in request.files:
        image = request.files['image']
        image_filename = secure_filename(image.filename)
        image_path = os.path.join('static/uploads', image_filename)
        image.save(image_path)
        card.image_url = os.path.join('/static/uploads', image_filename)
    
    db.session.commit()
    
    return jsonify({'success': True, 'image_url': card.image_url})

app = Flask(__name__, static_folder='static', static_url_path='/static')

# Blueprint 등록
app.register_blueprint(bp)

if __name__ == "__main__":
    app.run(debug=True)