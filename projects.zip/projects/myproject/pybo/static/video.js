document.addEventListener('DOMContentLoaded', () => {
    loadMedia(); // 페이지가 로드될 때 loadMedia 함수를 호출하여 미디어 목록을 불러옴
});


// 동영상 추가 표시
function showAddVideoModal() {
    $('#addVideoModal').modal('show');
}

// 동영상 취소 버튼
function cancelAddVideo() {
    document.getElementById('addVideoForm').reset();
    $('#addVideoModal').modal('hide');
}

// 동영상 수정 모달 열기
function showEditVideoModal(videoId) {
    // 기존 동영상 정보를 가져와서 폼에 채워넣는 로직을 추가할 수 있습니다.
    $('#editVideoModal').modal('show');
}

// 동영상 수정 모달 닫기
function cancelEditVideo() {
    $('#editVideoModal').modal('hide');
}





// 로컬 스토리지에서 동영상 로드 함수
function loadVideosFromLocalStorage() {
    const videos = JSON.parse(localStorage.getItem('videos')) || []; // 로컬 스토리지에서 동영상 목록 가져오기
    videos.forEach(video => {
        appendVideoCard(video); // 동영상 카드 추가
    });
}

// 로컬 스토리지에 동영상 저장 함수
function saveVideosToLocalStorage(videos) {
    localStorage.setItem('videos', JSON.stringify(videos)); // 동영상 목록을 JSON 형식으로 저장
}

// 동영상추가 
function appendVideoCard(video) {
    var cardHtml = `
    <div class="col">
                <div class="card h-100">
                    <video class="card-img-top" controls>
                        <source src="${video.file}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <div class="card-body">
                        <h5 class="card-title">${video.title}</h5>
                        <p class="card-text">${video.description}</p>
                        <button class="btn btn-warning" onclick="showEditVideoModal(${video.id})">Edit</button> <!-- 수정 버튼 추가 -->
                        <button class="btn btn-danger" onclick="deleteVideo(${video.id})">Delete</button> <!-- 삭제 버튼 추가 -->
                    </div>
                </div>
            </div>`;
    $('#videoCardContainer').append(cardHtml); // 동영상 카드를 컨테이너에 추가
}

// 문서 준비 완료 시 실행되는 함수
$(document).ready(function () {
    loadVideosFromLocalStorage(); // 로컬 스토리지에서 동영상 로드

    // 동영상 추가 폼 제출 이벤트 처리
    $('#addVideoForm').on('submit', function (e) {
        e.preventDefault(); // 폼 기본 제출 동작 방지

        var videoTitle = $('#videoTitle').val(); // 제목 가져오기
        var videoDescription = $('#videoDescription').val(); // 설명 가져오기
        var videoFile = URL.createObjectURL($('#videoFile')[0].files[0]); // 파일 가져오기

        var video = {
            id: Date.now(), // 고유 ID 생성
            title: videoTitle, // 제목 설정
            description: videoDescription, // 설명 설정
            file: videoFile // 파일 설정
        };


        var videos = JSON.parse(localStorage.getItem('videos')) || []; // 로컬 스토리지에서 동영상 목록 가져오기
        videos.push(video); // 동영상 목록에 새 동영상 추가
        saveVideosToLocalStorage(videos); // 로컬 스토리지에 동영상 목록 저장

        appendVideoCard(video); // 동영상 카드 추가

        $('#addVideoModal').modal('hide'); // 모달 닫기
        this.reset(); // 폼 초기화
    });

    // 동영상 수정 폼 제출 이벤트 처리
    $('#editVideoForm').on('submit', function (e) {
        e.preventDefault(); // 폼 기본 제출 동작 방지
        // 동영상 수정 로직을 추가합니다.
        $('#editVideoModal').modal('hide'); // 모달 닫기
    });
});

// 동영상 삭제 함수
function deleteVideo(videoId) {
    var videos = JSON.parse(localStorage.getItem('videos')) || []; // 로컬 스토리지에서 동영상 목록 가져오기
    videos = videos.filter(video => video.id !== videoId); // 해당 동영상 ID를 제외한 목록으로 필터링
    saveVideosToLocalStorage(videos); // 로컬 스토리지에 동영상 목록 저장
    location.reload(); // 페이지 새로고침하여 변경사항 반영
}

function loadMedia() {
    fetch('/media/list', {
        method: 'GET'
    }).then(response => response.json())
        .then(media => {
            document.getElementById('mediaContainer').innerHTML = ''; // 미디어 컨테이너 초기화
            media.forEach(item => {
                const newMedia = document.createElement('div'); // 새 div 요소 생성
                newMedia.className = 'col'; // 클래스 설정
                newMedia.dataset.id = item.id; // 데이터 속성에 미디어 ID 설정
                if (item.type === 'video') {
                    newMedia.innerHTML = `
                    <div class="card h-100">
                        <video controls class="card-img-top">
                            <source src="${item.url}" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                        <div class="card-body">
                            <h5 class="card-title">${item.title}</h5>
                            <p class="card-text">${item.description}</p>
                            <button class="btn btn-primary" onclick="showEditMediaModal(this)">수정</button>
                            <button class="btn btn-danger" onclick="deleteMedia(this)">삭제</button>
                        </div>
                    </div>
                `;
            } else {
                newMedia.innerHTML = `
                    <div class="card h-100">
                        <img src="${item.url}" class="card-img-top" alt="Media image">
                        <div class="card-body">
                            <h5 class="card-title">${item.title}</h5>
                            <p class="card-text">${item.description}</p>
                            <button class="btn btn-primary" onclick="showEditMediaModal(this)">수정</button>
                            <button class="btn btn-danger" onclick="deleteMedia(this)">삭제</button>
                        </div>
                    </div>
                `;
                }
                document.getElementById('mediaContainer').appendChild(newMedia); // 미디어 컨테이너에 새 미디어 추가
            });
        }).catch(error => {
            console.error('Error:', error);
        });
}